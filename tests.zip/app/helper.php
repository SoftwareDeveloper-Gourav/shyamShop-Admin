<?php

function test(){
   return "test";
}